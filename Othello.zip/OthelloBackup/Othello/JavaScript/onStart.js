document.getElementById("position44").style.backgroundColor = "white";
document.getElementById("position45").style.backgroundColor = "black";
document.getElementById("position54").style.backgroundColor = "black";
document.getElementById("position55").style.backgroundColor = "white";